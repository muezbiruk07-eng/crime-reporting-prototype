<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Actor</title>
    <link rel="stylesheet" href="Form.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cabin:ital,wght@0,400..700;1,400..700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php require 'Update.php'; ?>
    <div class="nav-top">
        <div class="logo">
            <img src="Logo-tiny.png">
        </div>
        <div class="nav-top-right">
            <div class="logout"><a href="Home.html">Home</a></div>
            <div class="logout"><a href="Home.html">Logout</a></div>
        </div>
    </div>
    <div class="rows">
    <div class="nav-left">
        <div class="inline-nav">
            <div class="add"><i class="fa fa-plus-square-o"></i>  <a href="Chief.html">Add Actors</a></div>
            <div class="update"><i class="fa fa-pencil-square-o"></i>  <a href="Chief2.html">Update Actors</a></div>
            <div class="remove"><i class="fa fa-trash-o"></i>  <a href="Chief3.html">Remove Actors</a></div>
        </div>
    </div>
    <div class="main">
        <div class="main1">
        <div class="info">
            <p>Update information about police officers here.</p>
        </div>
        <div class="login">
            <form class="login-form" method="POST" action="your-server-endpoint">
                <h2>Update Actor</h2>
            
                <div class="form-group">
                    <label for="aid">Actor ID:</label>
                    <input type="text" id="aid" name="aid" pattern="[A-Za-z]{1,2}[0-9]{2}" placeholder="Enter ID (e.g., L01)" required>
                </div>
            
                <div class="form-group">
                    <label for="fullname">Full Name:</label>
                    <input type="text" id="fullname" name="fullname" pattern="[A-Za-z\s]+" placeholder="Enter full name" required>
                    <i class="fa fa-user-o" aria-hidden="true"></i>
                </div>
            
                <div class="form-group">
                    <label for="fullname">Age:</label>
                    <input type="number" id="age" name="age" min="18" max="65" placeholder="Enter Age" required>
                </div>
            
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <select id="sex" name="sex" required>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="role">Role:</label>
                    <select id="role" name="role" required>
                        <option value="chief">Chief</option>
                        <option value="vicechief">Vice Chief</option>
                        <option value="logistic">Logistic</option>
                        <option value="inspector">Inspector</option>
                        <option value="detective">Detective</option>
                        <option value="patrolunit">Patrol Unit</option>
                        <option value="surgin">Surgin</option>
                    </select>
                </div>
            
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" placeholder="Enter Email" required>
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                </div>
            
                <div class="form-group">
                    <button type="submit" class="btn">Update</button>
                    <button type="reset" class="btn">Clear</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</body>
</html>